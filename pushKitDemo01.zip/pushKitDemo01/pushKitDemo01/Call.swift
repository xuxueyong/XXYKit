//
//  Call.swift
//  pushKitDemo01
//
//  Created by Tyler Cloud on 2020/3/9.
//  Copyright © 2020 Tyler Cloud. All rights reserved.
//

import Foundation
import AVKit
import Intents

enum CallState {
    case connecting // 正在连接
    case active     // 正在通话中
    case held       // 挂起
    case ended      // 结束电话
    case muted      // 麦克风静音
}

enum ConnectedState {
    case pending
    case complete
}

class Call {
    let uuid: UUID // 来电唯一标识
    let outgoing: Bool // 来电， 还是拨打
    let handle: String // 对放电话号码
    
    var callState: CallState = .ended {
        didSet {
            callStateChanged?()
        }
    }
    
    var connectedState: ConnectedState = .pending {
        didSet {
            connectedStateChanged?()
        }
    }
    
    var callStateChanged:(() -> Void)?
    var connectedStateChanged:(() -> Void)?
    
    init(uuid: UUID, outgoing: Bool = false, handle: String) {
        self.uuid = uuid
        self.outgoing = outgoing
        self.handle = handle
    }
    
    func start(completion:((_ success: Bool) -> Void)?) {
        completion?(true)
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 3) {
            self.callState = .connecting
            self.connectedState = .pending
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1.5) {
                self.callState = .active
                self.connectedState = .complete
            }
        }
    }
    
    func answer()  {
        callState = .active
    }
    
    func end() {
        callState = .ended
    }
}


class XYAudio {
    
    static func configAudioSession() {
        let session = AVAudioSession.sharedInstance()
        
        do {
            if #available(iOS 10.0, *) {
               try session.setCategory(AVAudioSession.Category.playAndRecord, mode: AVAudioSession.Mode.voiceChat, options: [])
            }
            
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    static func startAudio() {
        print("开始播放音乐")
    }
    
    static func stopAudio() {
        print("停止播放音乐")
    }
}


// 从系统的通话记录拨打 APP 的电话
protocol StartCallConvertible {
    var startCallHandle: String? { get }
    var video: Bool? { get }
}

extension StartCallConvertible {
    var video: Bool? {
        return nil
    }
}

@available(iOS 10.0, *)
protocol SupportedStartCallIntent {
    var contacts: [INPerson]? { get }
}

@available(iOS 10.0, *)
extension INStartAudioCallIntent: SupportedStartCallIntent {}
@available(iOS 10.0, *)
extension INStartVideoCallIntent: SupportedStartCallIntent {}

extension NSUserActivity: StartCallConvertible {
    
    var startCallHandle: String? {
        if #available(iOS 10.0, *) {
            guard
                let interaction = interaction,
                let startCallIntent = interaction.intent as? SupportedStartCallIntent,
                let contact = startCallIntent.contacts?.first
                else {
                    return nil
            }
            return contact.personHandle?.value
        }
        
        return nil
    }
    
    var video: Bool? {
        if #available(iOS 10.0, *) {
            guard
                let interaction = interaction,
                let startCallIntent = interaction.intent as? SupportedStartCallIntent
                else {
                    return nil
            }
            
            return startCallIntent is INStartVideoCallIntent
        }
        return nil
    }
}

