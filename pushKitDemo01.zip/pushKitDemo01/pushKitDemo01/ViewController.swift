//
//  ViewController.swift
//  pushKitDemo01
//
//  Created by Tyler Cloud on 2020/3/2.
//  Copyright © 2020 Tyler Cloud. All rights reserved.
//

import UIKit
import AVKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        if #available(iOS 10.0, *) {
            _ =  ProviderDelegate.shared
        }
        
        
        // 关于系统扬声器与听筒的切换
        NotificationCenter.default.addObserver(forName: AVAudioSession.routeChangeNotification, object: nil, queue: OperationQueue.main) {[weak self] (noti) in
            guard let w = self else { return }
            if #available(iOS 10.0, *) {
                let route = AVAudioSession.sharedInstance().currentRoute
                for desc in route.outputs {
                    if desc.portType.rawValue == "Speaker" {
                        // "免提功能已开启"
                    } else {
                        // "对方已接通，请使用听筒接听"
                    }
                }
            }
        }
    }

    @IBAction func PhoneAction(_ sender: Any) {
        if #available(iOS 10.0, *) {
            CallKitManager.shared.startCall(handle:"15872758374", videoEnabled: false)
        } else {
            //原来打电话的逻辑
        }
    }
    
    // 接电话
    @IBAction func phoneAnswerAction(_ sender: Any) {
        if #available(iOS 10.0, *) {
            ProviderDelegate.shared.reportIncomingCall(uuid: UUID(), handle: "15872758374", completion: { (error) in
                if let e = error {
                    print("CallKit& displayIncomingCall Error \(e)")
                }
            })
        }
    }
    
    // 结束电话
    @IBAction func phoneEndedAction(_ sender: Any) {
        if #available(iOS 10.0, *) {
            if let call = CallKitManager.shared.calls.first { //因为我们这里不支持群通话，所以一次只有一个call
                CallKitManager.shared.end(call: call)
            }
        }
    }
    
    // 挂起电话
    @IBAction func phoneHangUpAction(_ sender: Any) {
        if #available(iOS 10.0, *) {
            if let call = CallKitManager.shared.calls.first {
                CallKitManager.shared.setHeld(call: call, onHold: true)
            }
        }
    }
    
    // 麦克风静音
    func phoneMuted() {
        if #available(iOS 10.0, *) {
            if let call = CallKitManager.shared.calls.first {
                CallKitManager.shared.setMute(call: call, muted: true)
            }
        }
    }
}

