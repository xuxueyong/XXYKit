# ExHealthKit

[![CI Status](https://img.shields.io/travis/xueyong_xu/ExHealthKit.svg?style=flat)](https://travis-ci.org/xueyong_xu/ExHealthKit)
[![Version](https://img.shields.io/cocoapods/v/ExHealthKit.svg?style=flat)](https://cocoapods.org/pods/ExHealthKit)
[![License](https://img.shields.io/cocoapods/l/ExHealthKit.svg?style=flat)](https://cocoapods.org/pods/ExHealthKit)
[![Platform](https://img.shields.io/cocoapods/p/ExHealthKit.svg?style=flat)](https://cocoapods.org/pods/ExHealthKit)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

ExHealthKit is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'ExHealthKit'
```

## Author

xueyong_xu, xueyong_xu@yunzhijia.com

## License

ExHealthKit is available under the MIT license. See the LICENSE file for more info.
