//
//  YZJPedometerManager.h
//  Expedometer
//
//  Created by Tyler Cloud on 2020/3/2.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface YZJHealthManager : NSObject

+ (instancetype)shardManager;

// 上传数据
+ (void)uploadStepCountData;

// 授权
- (void)authorizeHealthKit:(void(^)(BOOL success, NSError *error))compltion;

// 获取步数
- (void)getStepCount:(void(^)(double value, NSError *error))completion;

// 获取距离
- (void)getDistance:(void(^)(double value, NSError *error))completion;

@end

NS_ASSUME_NONNULL_END
