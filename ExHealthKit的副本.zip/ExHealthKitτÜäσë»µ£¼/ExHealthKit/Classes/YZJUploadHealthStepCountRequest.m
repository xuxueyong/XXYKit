//
//  YZJUploadHealthStepCountRequest.m
//  ExHealthKit
//
//  Created by Tyler Cloud on 2020/3/5.
//

#import "YZJUploadHealthStepCountRequest.h"
@import KDLogin;

@interface YZJUploadHealthStepCountRequest()

@property (nonatomic, copy) NSDictionary *parameters;

@end

@implementation YZJUploadHealthStepCountRequest

- (instancetype)initWithUploadData:(NSArray *)data {
    self = [super init];
    if (self) {
        NSDictionary *dic = @{ @"token": [BOSConfig sharedConfig].user.token};
        self.parameters = dic;
    }
    return self;
}

- (NSString *)requestUrl {
    return @"/openaccess/uploadata";
}

- (KDRequestSerializer)requestSerializer {
    return KDRequestHTTPSerializer;
}

- (id)requestParameters {
    return self.parameters;
}

@end
