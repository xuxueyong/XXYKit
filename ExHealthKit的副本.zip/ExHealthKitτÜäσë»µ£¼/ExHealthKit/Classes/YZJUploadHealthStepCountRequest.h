//
//  YZJUploadHealthStepCountRequest.h
//  ExHealthKit
//
//  Created by Tyler Cloud on 2020/3/5.
//

#import <Foundation/Foundation.h>
@import KDNetworkBiz;

NS_ASSUME_NONNULL_BEGIN

@interface YZJUploadHealthStepCountRequest : KDBusinessRequest;

- (instancetype)initWithUploadData:(NSArray *)data;

@end

NS_ASSUME_NONNULL_END
