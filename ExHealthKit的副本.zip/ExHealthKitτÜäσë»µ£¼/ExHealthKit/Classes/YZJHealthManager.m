//
//  YZJPedometerManager.m
//  Expedometer
//
//  Created by Tyler Cloud on 2020/3/2.
//

#import "YZJHealthManager.h"
#import "YZJUploadHealthStepCountRequest.h"
@import CoreMotion;
@import HealthKit;
@import DeviceCheck;
@import KDLogin;

#define HKVersion [[[UIDevice currentDevice] systemVersion] doubleValue]
#define CustomHealthErrorDomain @"com.yzj.healthError"
// 记录最后最新登录的用户ID
#define kLastUserLoginUseridKey @"last_user_login_uid_key"
// 记录用户开始计步的时间
#define kUserStartStepTimeKey @"user_start_step_time_key"
// 记录用户数据上传的最后时间
#define kUserUploadLastTimeKey @"user_upload_last_time_key"

@interface YZJHealthManager ()

@property (nonatomic, strong) HKHealthStore *healthStore;
@property (nonatomic, strong) CMPedometer *pedometer;

@end

@implementation YZJHealthManager

+ (instancetype)shardManager {
    static YZJHealthManager *manger = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manger = [[[self class] alloc] init];
    });
    return manger;
}

/*
 *  @brief  检查是否支持获取健康数据
 */
- (void)authorizeHealthKit:(void(^)(BOOL success, NSError *error))compltion
{
    if(HKVersion >= 8.0)
    {
        if (![HKHealthStore isHealthDataAvailable]) {
            NSError *error = [NSError errorWithDomain: @"com.raywenderlich.tutorials.healthkit" code: 2 userInfo: [NSDictionary dictionaryWithObject:@"HealthKit is not available in th is Device"                                                                      forKey:NSLocalizedDescriptionKey]];
            if (compltion != nil) {
                compltion(false, error);
            }
            return;
        }
        if ([HKHealthStore isHealthDataAvailable]) {
            NSSet *readDataTypes = [YZJHealthManager dataTypesRead];
            
            /*
             注册需要读写的数据类型，也可以在“健康”APP中重新修改
             */
            [self.healthStore requestAuthorizationToShareTypes:nil readTypes:readDataTypes completion:^(BOOL success, NSError *error) {
                
                if (compltion != nil) {
                    NSLog(@"error->%@", error.localizedDescription);
                    compltion (success, error);
                }
            }];
        }
        
    }
    else {
        NSDictionary *userInfo = [NSDictionary dictionaryWithObject:@"iOS 系统低于8.0"                                                                      forKey:NSLocalizedDescriptionKey];
        NSError *aError = [NSError errorWithDomain:CustomHealthErrorDomain code:0 userInfo:userInfo];
        compltion(0,aError);
    }
}

#pragma mark - 上传数据
+ (void)uploadStepCountData {
    // 判断是否登录
    [BOSConfig sharedConfig].user.token = @"token";
    [BOSConfig sharedConfig].user.userId = @"123456";
    NSString *token = [BOSConfig sharedConfig].user.token;
    NSString *currentUid = [BOSConfig sharedConfig].user.userId;
    if (token.length > 0) {
        NSString *lastUid = [[NSUserDefaults standardUserDefaults] objectForKey:kLastUserLoginUseridKey];
        if (lastUid && [lastUid isEqualToString:currentUid]) {
            
            NSNumber *timeNumStart = [[NSUserDefaults standardUserDefaults] objectForKey:kUserStartStepTimeKey];
            NSNumber *timeNumlast = [[NSUserDefaults standardUserDefaults] objectForKey:kUserUploadLastTimeKey];
            if (![timeNumStart isEqualToNumber:timeNumlast]) {
                [self getStepCountWithStartTime:timeNumStart LastTime:timeNumlast];
            }
        } else { // 首次登录、或者切换账号
            NSTimeInterval interval = [[NSDate date] timeIntervalSince1970];
            [[NSUserDefaults standardUserDefaults] setObject:@(interval) forKey:kUserStartStepTimeKey];
            [[NSUserDefaults standardUserDefaults] setObject:@(interval) forKey:kUserUploadLastTimeKey];
            [[NSUserDefaults standardUserDefaults] setObject:currentUid forKey:kLastUserLoginUseridKey];
            [[NSUserDefaults standardUserDefaults] synchronize];
        }
    }
}

// 发起上传数据请求
+ (void)uploadDataWithArray:(NSArray *)data {
    YZJUploadHealthStepCountRequest *request = [[YZJUploadHealthStepCountRequest alloc] initWithUploadData:data];
    [request startCompletionBlockWithSuccess:^(__kindof KDRequest * _Nonnull request) {
        // 最后上传数据时间更新
        NSTimeInterval interval = [[NSDate date] timeIntervalSince1970];
        [[NSUserDefaults standardUserDefaults] setObject:@(interval) forKey:kUserUploadLastTimeKey];
    } failure:^(__kindof KDRequest * _Nonnull request) {
        NSLog(@"上传计步数据失败%@", request.response.error.errorMessage);
    }];
}

// 根据时间，获取每一天的步数
+ (void)getStepCountWithStartTime:(NSNumber *)startTimeIntervalNum LastTime:(NSNumber *)LastTimeIntervalNum {
    NSTimeInterval startInterval = [startTimeIntervalNum doubleValue];
    NSTimeInterval lastInterval = [LastTimeIntervalNum doubleValue];
    NSDate *nowDate = [NSDate date];
    NSDate *startDate = [NSDate dateWithTimeIntervalSince1970:startInterval];
    NSDate *lastDate = [NSDate dateWithTimeIntervalSince1970:lastInterval];
    
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *startComponents = [calendar components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay fromDate:startDate];
    NSDateComponents *lastComponents = [calendar components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay fromDate:lastDate];
    NSDateComponents *currentComponents = [calendar components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay fromDate:nowDate];
    if (currentComponents.year == startComponents.year && currentComponents.month == startComponents.month && currentComponents.day == startComponents.day) {  // 获取第一天的步数
        YZJHealthManager *manage = [YZJHealthManager shardManager];
        [manage authorizeHealthKit:^(BOOL success, NSError *error) {
            if (success) {
                [manage getStepCount:^(double value, NSError *error) {
                    NSString *stepCount = [NSString stringWithFormat:@"%.0f", value];
                    NSTimeInterval timestamp = [[NSDate date] timeIntervalSince1970];
                    NSArray *data = @[@{@"timestamp": @(timestamp), @"stepCount": stepCount}];
                    [self uploadDataWithArray:data];
                } withStartDate:startDate endDate:nowDate];
            }
        }];
    } else if (!(currentComponents.year == lastComponents.year && currentComponents.month == lastComponents.month && currentComponents.day == lastComponents.day)) {
        // 最后更新时间 -- 到现在的数据
        NSDateComponents *components = [calendar components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay fromDate:lastDate];
        [components setHour:0];
        [components setMinute:0];
        [components setSecond: 0];
        
        NSInteger countDay = [YZJHealthManager numberOfDaysWithFromDate:lastDate toDate:nowDate];
        NSMutableArray *uploadData = [NSMutableArray arrayWithCapacity:countDay];
        NSDate *newLastDate = [calendar dateFromComponents:components];
        for (NSInteger i = 0; i < countDay; i++) {
            NSDate *nextDate = [calendar dateByAddingUnit:NSCalendarUnitDay value:1 toDate:newLastDate options:0];
            newLastDate = nextDate;
            YZJHealthManager *manage = [YZJHealthManager shardManager];
            [manage authorizeHealthKit:^(BOOL success, NSError *error) {
                if (success) {
                    [manage getStepCount:^(double value, NSError *error) {
                        NSString *stepCount = [NSString stringWithFormat:@"%.0f", value];
                        NSTimeInterval upload_timestamp = [newLastDate timeIntervalSince1970];
                        NSDictionary *dic = @{@"timestamp": @(upload_timestamp), @"stepCount": stepCount};
                        [uploadData addObject:dic];
                    } withStartDate:startDate endDate:nowDate];
                }
            }];
        }
        
        [YZJHealthManager uploadDataWithArray:uploadData];
    }
}

//获取步数
- (void)getStepCount:(void(^)(double value, NSError *error))completion
{
    HKQuantityType *quantityType = [HKQuantityType quantityTypeForIdentifier:HKQuantityTypeIdentifierStepCount];
    HKStatisticsQuery *query = [[HKStatisticsQuery alloc]initWithQuantityType:quantityType quantitySamplePredicate:[YZJHealthManager predicateForSamplesToday] options:HKStatisticsOptionCumulativeSum completionHandler:^(HKStatisticsQuery * _Nonnull query, HKStatistics * _Nullable result, NSError * _Nullable error) {
        if (error) {
            [self getCMPStepCount: completion];
        } else {
            double stepCount = [result.sumQuantity doubleValueForUnit:[HKUnit countUnit]];
            NSLog(@"当天行走步数 = %lf",stepCount);
            if(stepCount > 0){
                if (completion) {
                    completion(stepCount,nil);
                }
            } else {
                [self getCMPStepCount: completion];
            }
        }
        
    }];
    [self.healthStore executeQuery:query];
}

// 根据开始时间和结束时间获取步数
- (void)getStepCount:(void(^)(double value, NSError *error))completion withStartDate:(NSDate *)startDate endDate:(NSDate *)endDate
{
    HKQuantityType *quantityType = [HKQuantityType quantityTypeForIdentifier:HKQuantityTypeIdentifierStepCount];
    NSPredicate *predicate = [HKQuery predicateForSamplesWithStartDate:startDate endDate:endDate options:HKQueryOptionNone];
    HKStatisticsQuery *query = [[HKStatisticsQuery alloc]initWithQuantityType:quantityType quantitySamplePredicate:predicate options:HKStatisticsOptionCumulativeSum completionHandler:^(HKStatisticsQuery * _Nonnull query, HKStatistics * _Nullable result, NSError * _Nullable error) {
        if (error) {
            completion(0,error);
        } else {
            double stepCount = [result.sumQuantity doubleValueForUnit:[HKUnit countUnit]];
            NSLog(@"一段时间行走步数 = %lf",stepCount);
            if(stepCount > 0){
                if (completion) {
                    completion(stepCount,nil);
                }
            } else {
                completion(0,nil);
            }
        }
        
    }];
    [self.healthStore executeQuery:query];
}

//获取公里数
- (void)getDistance:(void(^)(double value, NSError *error))completion
{
    HKQuantityType *distanceType = [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierDistanceWalkingRunning];
    NSSortDescriptor *timeSortDescriptor = [[NSSortDescriptor alloc] initWithKey:HKSampleSortIdentifierEndDate ascending:NO];
    HKSampleQuery *query = [[HKSampleQuery alloc] initWithSampleType:distanceType predicate:[YZJHealthManager predicateForSamplesToday] limit:HKObjectQueryNoLimit sortDescriptors:@[timeSortDescriptor] resultsHandler:^(HKSampleQuery * _Nonnull query, NSArray<__kindof HKSample *> * _Nullable results, NSError * _Nullable error) {
        
        if(error)
        {
            completion(0,error);
        }
        else
        {
            double totleSteps = 0;
            for(HKQuantitySample *quantitySample in results)
            {
                HKQuantity *quantity = quantitySample.quantity;
                HKUnit *distanceUnit = [HKUnit meterUnitWithMetricPrefix:HKMetricPrefixKilo];
                double usersHeight = [quantity doubleValueForUnit:distanceUnit];
                totleSteps += usersHeight;
            }
            NSLog(@"当天行走距离 = %.2f",totleSteps);
            completion(totleSteps,error);
        }
    }];
    [self.healthStore executeQuery:query];
}

#pragma mark - 获取协处理器步数
- (void)getCMPStepCount:(void(^)(double stepCount, NSError *error))completion
{
    if ([CMPedometer isStepCountingAvailable] && [CMPedometer isDistanceAvailable]) {
        NSCalendar *calendar = [NSCalendar currentCalendar];
        NSDate *now = [NSDate date];
        NSDateComponents *components = [calendar components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay fromDate:now];
        // 开始时间
        NSDate *startDate = [calendar dateFromComponents:components];
        // 结束时间
        NSDate *endDate = [calendar dateByAddingUnit:NSCalendarUnitDay value:1 toDate:startDate options:0];
        [self.pedometer queryPedometerDataFromDate:startDate toDate:endDate withHandler:^(CMPedometerData * _Nullable pedometerData, NSError * _Nullable error) {
            if (error) {
                if(completion) completion(0 ,error);
                [self goAppRunSettingPage];
            } else {
                double stepCount = [pedometerData.numberOfSteps doubleValue];
                if(completion)
                completion(stepCount ,error);
            }
            [self.pedometer stopPedometerUpdates];
        }];
    }
}

/*!
 *  @brief  读权限
 *  @return 集合
 */
+ (NSSet *)dataTypesRead
{
    HKQuantityType *stepCountType = [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierStepCount];
    HKQuantityType *distance = [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierDistanceWalkingRunning];
    return [NSSet setWithObjects:stepCountType,distance,nil];
}

/*!
 *  @brief  当天时间段
 *
 *  @return 时间段
 */
+ (NSPredicate *)predicateForSamplesToday {
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDate *now = [NSDate date];
    NSDateComponents *components = [calendar components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay fromDate:now];
    [components setHour:0];
    [components setMinute:0];
    [components setSecond: 0];
    
    NSDate *startDate = [calendar dateFromComponents:components];
    NSDate *endDate = [calendar dateByAddingUnit:NSCalendarUnitDay value:1 toDate:startDate options:0];
    NSPredicate *predicate = [HKQuery predicateForSamplesWithStartDate:startDate endDate:endDate options:HKQueryOptionNone];
    return predicate;
}

/*!
 *  @brief  一个时间段
 *
 *  @return 时间段
 */
+ (NSPredicate *)predicateForSamplesWtihStartDate:(NSDate *)startDate endDate:(NSDate *)endDate {
    NSPredicate *predicate = [HKQuery predicateForSamplesWithStartDate:startDate endDate:endDate options:HKQueryOptionNone];
    return predicate;
}

/**
 * 计算两个日期之间的天数
 */
+ (NSInteger)numberOfDaysWithFromDate:(NSDate *)fromDate toDate:(NSDate *)toDate{
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDateComponents *comp = [calendar components:NSCalendarUnitDay fromDate:fromDate toDate:toDate options:NSCalendarWrapComponents];
    return comp.day;
}

#pragma mark - 跳转App运动与健康设置页面
- (void)goAppRunSettingPage {
    NSString *appName = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleDisplayName"];
    NSString *msgStr = [NSString stringWithFormat:@"请在【设置->%@->%@】下允许访问权限",appName,@"运动与健身"];
    dispatch_async(dispatch_get_main_queue(), ^{
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"使用提示" message:msgStr delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"设置", nil];
        [alert show];
    });
}

#pragma mark - UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 1) {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
    }
}

#pragma mark - getter
- (HKHealthStore *)healthStore {
    if (!_healthStore) {
        _healthStore = [[HKHealthStore alloc] init];
    }
    return _healthStore;
}

- (CMPedometer *)pedometer {
    if (!_pedometer) {
        _pedometer = [[CMPedometer alloc] init];
    }
    return _pedometer;
}


- (void)readStepCountStr:(void (^)(NSString *countStr))completion {
    NSString *deviceName = @"iPhone";
    
    //从健康应用中获取权限
    [self.healthStore requestAuthorizationToShareTypes:nil readTypes:[YZJHealthManager dataTypesRead] completion:^(BOOL success, NSError * _Nullable error) {
        if (success)
        {
            NSDateFormatter *formatter = [[NSDateFormatter alloc ]init];
            [formatter setDateFormat:@"yyyy-MM-dd"];
            NSDate *now = [NSDate date];
            NSString *todaystr = [formatter stringFromDate:now];
            NSDate *today = [formatter dateFromString:todaystr];
            
            NSDate *next = [today dateByAddingTimeInterval:24*60*60];
            //定义需要获取的数据为步数
            HKQuantityType *quantityType = [HKQuantityType quantityTypeForIdentifier:HKQuantityTypeIdentifierStepCount];
            //设置获取的步数时间间隔
            NSDateComponents *dateComponents = [[NSDateComponents alloc] init];
            dateComponents.day = 1;
            
            NSPredicate *predicate = [HKQuery predicateForSamplesWithStartDate:today endDate:next options:HKQueryOptionStrictStartDate];
            //创建查询统计对象collectionQuery
            HKStatisticsCollectionQuery *collectionQuery = [[HKStatisticsCollectionQuery alloc] initWithQuantityType:quantityType quantitySamplePredicate:predicate options: HKStatisticsOptionCumulativeSum | HKStatisticsOptionSeparateBySource anchorDate:[NSDate dateWithTimeIntervalSince1970:0] intervalComponents:dateComponents];
            collectionQuery.initialResultsHandler = ^(HKStatisticsCollectionQuery *query, HKStatisticsCollection * __nullable result, NSError * __nullable error) {
                float numberOfSteps = 0;
                for (HKStatistics *statistic in result.statistics) {
                    
                    for (HKSource *source in statistic.sources) {
                        //HKSource对象中的name可用于区分健康数据来源
                        if ([source.name isEqualToString:deviceName]) {
                            float steps = [[statistic sumQuantityForSource:source] doubleValueForUnit:[HKUnit countUnit]];
                            numberOfSteps += steps;
                            
                        }
                        //deviceName是根据接入的设备做的标记,
                        if ([deviceName isEqualToString:@"iPhone"]) {
                            if ([source.name isEqualToString:[UIDevice currentDevice].name]) {
                                float steps = [[statistic sumQuantityForSource:source] doubleValueForUnit:[HKUnit countUnit]];
                                numberOfSteps += steps;
                                
                            }
                            
                        }else if ([deviceName isEqualToString:@"iWatch"] && ![source.name isEqualToString:[UIDevice currentDevice].name]){
                            if ([source.bundleIdentifier hasPrefix:@"com.apple.health"]) {
                                float steps = [[statistic sumQuantityForSource:source] doubleValueForUnit:[HKUnit countUnit]];
                                numberOfSteps += steps;
                                
                            }
                        }else if ([deviceName isEqualToString:@"xiaomi"]){
                            if ([source.name isEqualToString:@"小米运动"] || [source.bundleIdentifier isEqualToString:@"HM.wristband"]) {
                                float steps = [[statistic sumQuantityForSource:source] doubleValueForUnit:[HKUnit countUnit]];
                                numberOfSteps += steps;
                                
                            }
                            
                        }
                    }
                    
                }
                NSLog(@"ff = %f",numberOfSteps);
                NSString *stepString = [NSString stringWithFormat:@"%.0f",numberOfSteps];
                completion(stepString);
            };
            [self.healthStore executeQuery:collectionQuery];
        }
        else
        {
            NSLog(@"获取步数权限失败");
        }
    }];
}

@end
