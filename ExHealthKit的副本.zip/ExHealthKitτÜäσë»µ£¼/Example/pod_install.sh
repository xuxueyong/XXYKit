
#!/bin/sh

bundle exec pod install --no-repo-update
