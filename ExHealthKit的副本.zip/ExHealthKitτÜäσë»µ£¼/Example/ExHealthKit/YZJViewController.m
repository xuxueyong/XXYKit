//
//  YZJViewController.m
//  ExHealthKit
//
//  Created by xueyong_xu on 03/04/2020.
//  Copyright (c) 2020 xueyong_xu. All rights reserved.
//

#import "YZJViewController.h"
@import ExHealthKit;

@interface YZJViewController ()

@end

@implementation YZJViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
//    YZJHealthManager *manage = [YZJHealthManager shardManager];
//    [manage authorizeHealthKit:^(BOOL success, NSError *error) {
//
//        if (success) {
//
//            [manage getStepCount:^(double value, NSError *error) {
//                NSLog(@"1count-->%.0f", value);
//                NSLog(@"1error-->%@", error.localizedDescription);
//            }];
//
//        }
//
//    }];
    
    [YZJHealthManager uploadStepCountData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
