//
//  YZJAppDelegate.h
//  ExHealthKit
//
//  Created by xueyong_xu on 03/04/2020.
//  Copyright (c) 2020 xueyong_xu. All rights reserved.
//

@import UIKit;

@interface YZJAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
