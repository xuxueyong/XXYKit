//
//  main.m
//  ExHealthKit
//
//  Created by xueyong_xu on 03/04/2020.
//  Copyright (c) 2020 xueyong_xu. All rights reserved.
//

@import UIKit;
#import "YZJAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([YZJAppDelegate class]));
    }
}
